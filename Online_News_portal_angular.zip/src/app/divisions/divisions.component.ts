import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-divisions',
  templateUrl: './divisions.component.html',
  styleUrls: ['./divisions.component.css']
})
export class DivisionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
