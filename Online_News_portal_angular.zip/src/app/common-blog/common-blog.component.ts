import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-common-blog',
  templateUrl: './common-blog.component.html',
  styleUrls: ['./common-blog.component.css']
})
export class CommonBlogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
