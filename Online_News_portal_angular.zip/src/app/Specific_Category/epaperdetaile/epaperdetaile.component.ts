import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ServiceService } from 'src/app/Services/service.service';

@Component({
  selector: 'app-epaperdetaile',
  templateUrl: './epaperdetaile.component.html',
  styleUrls: ['./epaperdetaile.component.css']
})
export class EpaperdetaileComponent implements OnInit {

  constructor(
    private route: ActivatedRoute,
    private service: ServiceService
  ) { }
  blogId: any;
  blogByid: any;
  ngOnInit(): void {
    this.blogId = this.route.snapshot.params["blog_id"];

    this.blogByid = this.service.getBlogById(this.blogId).subscribe( (data: any) => {
      

        this.blogByid = data;
      })
  }

}
