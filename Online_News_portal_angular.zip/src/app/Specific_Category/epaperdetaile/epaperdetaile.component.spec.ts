import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EpaperdetaileComponent } from './epaperdetaile.component';

describe('EpaperdetaileComponent', () => {
  let component: EpaperdetaileComponent;
  let fixture: ComponentFixture<EpaperdetaileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EpaperdetaileComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EpaperdetaileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
