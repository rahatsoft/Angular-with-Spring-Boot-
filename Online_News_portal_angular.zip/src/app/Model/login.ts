export class Login {
    id: any;
    name: any;
    email: any;
    password: any;
    role: any;
    image:any;
    constructor(id: any, name: any, email: any, password: any, role: any, image:any) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.role = role;
        this.image = image;
    }

}

