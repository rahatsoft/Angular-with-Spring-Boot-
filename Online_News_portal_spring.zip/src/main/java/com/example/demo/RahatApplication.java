package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RahatApplication {

	public static void main(String[] args) {
		SpringApplication.run(RahatApplication.class, args);
	}

}
